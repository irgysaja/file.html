### Hi there 👋

<!--
**irgysaja/irgysaja** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
# Hi there, I'm irgysaja - aku [Irgysaja](https://www.youtube.com/channel/UC22xix7qvwpYWnSQ5QEYtAQ) 👋
## About me:
- 🔭 Saat ini saya bekerja di tidak
- 🌱 Saat ini saya sedang belajar Python, Java dan HTML
- 👯 saya ingin berkolabroasi sebagai mahasiswa rekayasa data dan pengetahuan dibidang mobile developer
- 🤔 Saya mencari saya menemukan karir saya di bidang aplikasi seluler
- 💬 Tanyakan padaku tentang apapun
- 📫 Cara menghubungi saya: irgysaja@gmail.com

## pendidikan:

#### 1. [Universitas Sanata Dharma](https://www.usd.ac.id/) | Informatika | Yogyakarta `2020-2023`
   - kepala departemen sosial himpunan mahasiswa informatika 2021-2022
   - kordinator dibidang humas panitia IASD 2022 
   - anggota panitia publikasi IT Days 2022
 #### 2. [SMA N 1 Siberut Selatan](https://sman1siberutselatan.sch.id/) | MIPA | Mentawai `2017-2020`
   - ketua OSIS   
   - anggota pramuka
   - anggota marching band

## keahlian :
     -mampu menguasai bahasa pemrogaman menggunakan bahasa java ,untuk membuat proyek perpustakaan
     -mampu menguasai python
     -belajar mengerjakan proyek website ,menggunakan javascript dan html

### bahasa dan alat:

[<img align="left" alt="netbeans" width="30px" src="https://netbeans.apache.org/images/apache-netbeans.svg" style="padding-right:10px;" />][webdev]
[<img align="left" alt="Python" width="30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/110px-Python-logo-notext.svg.png?20100317150552" style="padding-right:10px;" />][webdev]
[<img align="left" alt="jupiter" width="30px" src="https://jupyter.org/assets/homepage/main-logo.svg" />][webdev]

<br />
<br />

---
### 



[webdev]: https://github.com/irgysaja/irgysaja/edit/main/README.md
